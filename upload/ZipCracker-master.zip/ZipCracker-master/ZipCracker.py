# _*_ coding:utf-8 _*_
import sys
import zipfile
import getopt

# 字典文件路径
dict = ""
# zip文件路径
path = ""

# 获取参数
opts, args = getopt.getopt(sys.argv[1:], "hp:d:")
for opt, value in opts:
    if opt == "-p":
        path = value
    if opt == "-d":
        dict = value

# 开始破解
isZipFile = zipfile.is_zipfile(path)
if isZipFile:
    zipFile = zipfile.ZipFile(path)
    for f in zipFile.namelist():
        print "包含文件: " + f + "  "
    dict = open(dict)
    for passwd in dict.readlines():
        try:
            zipFile.extractall(pwd=passwd[:-1])  # 删除"\n"
            print "密码: " + passwd
            break
        except Exception, e:
            continue
else:
    print "not a zipfile"



