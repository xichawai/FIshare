# _*_ coding:utf-8 _*_



#  字典生成(破解6位数纯数字密码)
dict = open(name="dict", mode="w")
for index in range(1000000):
    dict.write(str(index) + "\n")
    dict.flush()
dict.close()
