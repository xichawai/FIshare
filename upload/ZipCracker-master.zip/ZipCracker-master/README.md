# ZipCracker
zip文件暴力破解器

运行ZipCracker.py
必要参数
-p zip文件路径
-d 字典文件路径

